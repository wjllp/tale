from dao import mydao
username = int(input('请输入学号：'))
mydao.shutdown_class(username)
