from crawler import *
username = input('学号：')
password = input('密码：')
email = input('邮箱：')
get_class(username,password,email)
