#coding:utf-8
from crawler import *
from dao import mydao
from sendmail import *
import datetime
import time
import logging

logging.basicConfig(filename='logs/sendscore.log',
                    format='%(asctime)s:  %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    level=10)

def sendscore():
    users = []
    term_info = mydao.select_current_term()[0]
    year = term_info['year']
    term = term_info['term']
    uncomment_scores = mydao.select_uncomment_score(year,term)
    for uncomment_score in uncomment_scores:          #如果有未评教，则打开分数推送开关更新分数
        mydao.start_score(uncomment_score['stu_id'])
    users = mydao.select_score_student()
    usercount = len(users)
    for user in users:
        total_scores_count = user['course_count']
        logging.info(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        logging.info (user['stu_id'],user['password'],user['email'],user['sname'])
        logging.info ('发送邮件的前一步')
        old_current_score_count = len(mydao.select_score(user['stu_id'],year,term))
        get_scores(str(user['stu_id']),user['password'],user['email'],user['sname'],total_scores_count,uncomment_scores)
        current_score_count = len(mydao.select_score(user['stu_id'],year,term))
        logging.info ('总课程数：%d'%total_scores_count,'当前已出课程数：%d'%current_score_count)
        if (current_score_count > old_current_score_count):
            logging.info("有新的成绩出来了")
        else:
            logging.info("今天没有出新成绩")
        if (total_scores_count == current_score_count):
            logging.info("所有成绩已出来")
            mydao.shutdown_score(user['stu_id'])
        logging.info ('发送邮件的后一步')
    return usercount

if __name__ == '__main__':
    a = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    starttime = time.time()
    usercount = sendscore()
    endtime = time.time()
    costtime = endtime-starttime
    logging.info ('开始时间：',a)
    logging.info ('结束时间：',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    logging.info ('用户数量：%d'%usercount,',耗费总时间(秒)：%0.2f'%costtime,',平均耗时(秒)：%0.2f'%(float(costtime/usercount)))
    text = "开始时间："+a+"\n结束时间："+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())+"\n用户数量："+str(usercount)+"\n耗费总时间：%0.2f"%costtime+"\n平均耗时：%0.2f"%float(costtime/usercount)
